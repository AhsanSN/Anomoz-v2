function JSalert_about_my_public(){
	swal({
  type: 'info',
  title: "About",
  text: 'This is your public wall. People post on your wall anonymously.<br><br><br><br><br><br><br><br><br><br> asdasd',
  html:
    'You can use <b>bold text</b>, ' +
    '<a href="//github.com">links</a> ' +
    'and other HTML tags',
})
}

