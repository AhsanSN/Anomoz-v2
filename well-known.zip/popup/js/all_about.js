function about_my_public() {
JSalert_about_my_public();
}
function about_their_public() {
JSalert_about_their_public();
}