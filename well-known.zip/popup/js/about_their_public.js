function JSalert_about_their_public(){
	swal({
  type: 'info',
  title: "About",
  text: 'This is someones else profile.<br><br><br><br><br><br><br><br><br><br> asdasd',
  html:
    'You can use <b>bold text</b>, ' +
    '<a href="//github.com">links</a> ' +
    'and other HTML tags',
})
}
