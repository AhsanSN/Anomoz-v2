<?
include_once("global.php");
print_r($_SESSION);
?>