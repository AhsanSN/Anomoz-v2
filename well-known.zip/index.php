<?
include_once('global.php');
?><?
if ($logged==1)
{
    include_once('home.php');
}
else{
    ?>
    <?
include_once('main_index.php');} ?>